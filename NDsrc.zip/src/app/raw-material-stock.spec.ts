import { RawMaterialStock } from './raw-material-stock';

describe('RawMaterialStock', () => {
  it('should create an instance', () => {
    expect(new RawMaterialStock()).toBeTruthy();
  });
});
