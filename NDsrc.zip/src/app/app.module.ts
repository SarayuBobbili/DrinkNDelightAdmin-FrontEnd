import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddRawMaterialComponent } from './add-raw-material/add-raw-material.component';
import { HttpClientModule } from '@angular/common/http';
import { FindRawMaterialComponent } from './find-raw-material/find-raw-material.component';
import { UpdateRawMaterialComponent } from './update-raw-material/update-raw-material.component';
import { FindsupplierComponent } from './findsupplier/findsupplier.component';
import { ViewsuppliersComponent } from './viewsuppliers/viewsuppliers.component';
import { UpdatesupplierComponent } from './updatesupplier/updatesupplier.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    AddRawMaterialComponent,
    FindRawMaterialComponent,
    UpdateRawMaterialComponent,
    FindsupplierComponent,
    ViewsuppliersComponent,
    UpdatesupplierComponent,
    SignupComponent,
    HomeComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
