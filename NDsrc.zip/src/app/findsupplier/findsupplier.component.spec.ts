import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindsupplierComponent } from './findsupplier.component';

describe('FindsupplierComponent', () => {
  let component: FindsupplierComponent;
  let fixture: ComponentFixture<FindsupplierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindsupplierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindsupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
