import { Component, OnInit } from '@angular/core';
import { DrinkanddelightService } from '../drinkanddelight.service';
import { Supplier } from '../supplier';
import { RawMaterialStock } from '../raw-material-stock';

@Component({
  selector: 'app-findsupplier',
  templateUrl: './findsupplier.component.html',
  styleUrls: ['./findsupplier.component.css']
})
export class FindsupplierComponent implements OnInit {

  supplierid:number;
  supplierdata:Supplier = new Supplier();
  rawmaterial:RawMaterialStock[] =[]; 

  errorMessage:string;
  constructor(private dadservice:DrinkanddelightService) { }

  ngOnInit(): void {
    this.rawmaterial=this.supplierdata.stock;
  }

  check():void
  {
    this.rawmaterial=this.supplierdata.stock;

  }

  findSupplier():void
  {
    this.dadservice.findSupplier(this.supplierid).subscribe((data)=>
    {
    this.supplierdata = data;
    this.errorMessage = undefined
    },
    error=>
    {
      this.errorMessage="Id not found";
    }
    );

  }


}
