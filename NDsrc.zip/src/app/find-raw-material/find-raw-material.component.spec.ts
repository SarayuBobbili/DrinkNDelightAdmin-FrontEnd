import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindRawMaterialComponent } from './find-raw-material.component';

describe('FindRawMaterialComponent', () => {
  let component: FindRawMaterialComponent;
  let fixture: ComponentFixture<FindRawMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindRawMaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindRawMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
