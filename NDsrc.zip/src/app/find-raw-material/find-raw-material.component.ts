import { Component, OnInit } from '@angular/core';
import { DrinkanddelightService } from '../drinkanddelight.service';
import { RawMaterialStock } from '../raw-material-stock';

@Component({
  selector: 'app-find-raw-material',
  templateUrl: './find-raw-material.component.html',
  styleUrls: ['./find-raw-material.component.css']
})
export class FindRawMaterialComponent implements OnInit {

  rawmaterial:RawMaterialStock = new RawMaterialStock();
  materialid:number;
  
  errorMessage:String;
  constructor(private dadservice:DrinkanddelightService) { }

  ngOnInit(): void {
  }

  findRawMaterial():void
  {

    this.dadservice.findRawMaterial(this.materialid).subscribe((data)=>
    {
      this.rawmaterial = data;
      this.errorMessage = undefined
    },
    error=>
    {
      this.errorMessage="Id not found.";
    }
    );
    
  }
}
