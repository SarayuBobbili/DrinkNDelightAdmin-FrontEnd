import { TestBed } from '@angular/core/testing';

import { DrinkanddelightService } from './drinkanddelight.service';

describe('DrinkanddelightService', () => {
  let service: DrinkanddelightService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DrinkanddelightService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
