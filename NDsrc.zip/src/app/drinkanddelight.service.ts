import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { RawMaterialStock } from './raw-material-stock';
import { Observable } from 'rxjs';
import { Supplier } from './supplier';


@Injectable({
  providedIn: 'root'
})
export class DrinkanddelightService {

  constructor(private http:HttpClient) { }

  addRawMaterial(rawmaterial:RawMaterialStock):Observable<any>
  {
    let url="http://localhost:1994/rawmaterial/new";
    return this.http.post(url,rawmaterial,{responseType:'text'});
  }

  findRawMaterial(rawMaterialId:number):Observable<any>
  {
    let url="http://localhost:1994/rawmaterial/"+ rawMaterialId;
    return this.http.get(url);
  }

  updateRawMaterial(material:RawMaterialStock):Observable<any>
  {
    let url="http://localhost:1994/rawmaterial/update/";
    return this.http.put(url,material,{responseType:'text'});
  }

  deleteRawMaterial(id:number):Observable<any>
  {
    let url="http://localhost:1994/rawmaterial/delete/"+id;
    return this.http.delete(url,{responseType:'text'});
  }

  viewSuppliers():Observable<any>
  {
    let url="http://localhost:1994/supplier/view";
    return this.http.get(url);
  }

  findSupplier(supplierid:number):Observable<any>
  {
    let url="http://localhost:1994/supplier/"+supplierid;
    return this.http.get(url);
  }

  updateSupplier(supplier:Supplier):Observable<any>
  {
    let url="http://localhost:1994/supplier/update";
    return this.http.put(url,supplier,{responseType:'text'});
  }
}
