import { Component, OnInit } from '@angular/core';
import { DrinkanddelightService } from '../drinkanddelight.service';
import { RawMaterialStock } from '../raw-material-stock';

@Component({
  selector: 'app-update-raw-material',
  templateUrl: './update-raw-material.component.html',
  styleUrls: ['./update-raw-material.component.css']
})
export class UpdateRawMaterialComponent implements OnInit {

  materialid:number;
  updatematerial:RawMaterialStock = new RawMaterialStock();
  errorMessage:String;
  errorMessage1:String;
  constructor(private dadservice:DrinkanddelightService) { }

  ngOnInit(): void {
  }

  searchMaterial():void
  {
    this.dadservice.findRawMaterial(this.materialid).subscribe(data=>
    {
      
        this.updatematerial=data
        this.errorMessage=undefined
     },
      error=>
        {
          this.errorMessage="Id not found.";
        }
        );
   }
  
  updateRawMaterial():void
  {
    this.dadservice.updateRawMaterial(this.updatematerial).subscribe(data=>
      {
        alert("Raw Material Updated");
        this.errorMessage1=undefined;
      },
        error=>
      {
        this.errorMessage1 ="Expiry date should be after manufacture date";
      }
      );
  }
}
  



