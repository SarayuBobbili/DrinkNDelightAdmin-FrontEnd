export class RawMaterialStock {
    
    rawMaterialId:number;
    rawMaterialName:string;
    rawMaterialQuantity:DoubleRange;
    rawMaterialPrice:DoubleRange;
    manufacturingDate:Date;
    expiryDate:Date;
}
