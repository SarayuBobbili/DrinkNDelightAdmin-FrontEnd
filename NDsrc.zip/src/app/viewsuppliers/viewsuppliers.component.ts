import { Component, OnInit } from '@angular/core';
import { DrinkanddelightService } from '../drinkanddelight.service';
import { Supplier } from '../supplier';

@Component({
  selector: 'app-viewsuppliers',
  templateUrl: './viewsuppliers.component.html',
  styleUrls: ['./viewsuppliers.component.css']
})
export class ViewsuppliersComponent implements OnInit {

  suppliers:Supplier[]=[];
  constructor(private dadservice:DrinkanddelightService) { }

  ngOnInit(): void {
    this.dadservice.viewSuppliers().subscribe(data=>this.suppliers=data);
  }
}
  