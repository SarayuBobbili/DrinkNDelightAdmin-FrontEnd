import { RawMaterialStock } from './raw-material-stock';

export class Supplier {

     supplierId:number;
     supplierName:string;
     supplierAddress:string;
     supplierPhone:BigInteger;
     stock:RawMaterialStock[];
     
}


