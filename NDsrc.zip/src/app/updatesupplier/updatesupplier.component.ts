import { Component, OnInit } from '@angular/core';
import { DrinkanddelightService } from '../drinkanddelight.service';
import { Supplier } from '../supplier';

@Component({
  selector: 'app-updatesupplier',
  templateUrl: './updatesupplier.component.html',
  styleUrls: ['./updatesupplier.component.css']
})
export class UpdatesupplierComponent implements OnInit {

  supplierid:number;
  updatesupplier:Supplier = new Supplier();
  errorMessage:String;

  constructor(private dadservice:DrinkanddelightService) { }

  ngOnInit(): void {
  }
  searchSupplier():void
  {
    this.dadservice.findSupplier(this.supplierid).subscribe(data=>
    {
        this.updatesupplier=data
        this.errorMessage=undefined
     },
      error=>
        {
          this.errorMessage="Id not found.";
        }
        );
   }

   updateSupplier():void
   {
     this.dadservice.updateSupplier(this.updatesupplier).subscribe(data=>
      {
        alert(" Supplier Updated");
      },
      error=>
      {
        console.log("There is some error.",error);
      }
      )
   }
}
