import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddRawMaterialComponent } from './add-raw-material/add-raw-material.component';
import { FindRawMaterialComponent } from './find-raw-material/find-raw-material.component';
import { UpdateRawMaterialComponent } from './update-raw-material/update-raw-material.component';
import { FindsupplierComponent } from './findsupplier/findsupplier.component';
import { ViewsuppliersComponent } from './viewsuppliers/viewsuppliers.component';
import { UpdatesupplierComponent } from './updatesupplier/updatesupplier.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  {path:'addmaterial',component:AddRawMaterialComponent},
  {path:'findmaterial',component:FindRawMaterialComponent},
  {path:'updatematerial',component:UpdateRawMaterialComponent},
  {path:'viewsuppliers',component:ViewsuppliersComponent},
  {path:'findsupplier',component:FindsupplierComponent},
  {path:'updatesupplier',component:UpdatesupplierComponent},
  {path:'signup',component:SignupComponent},
  {path:'home',component:HomeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
