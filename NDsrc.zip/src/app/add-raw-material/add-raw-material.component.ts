import { Component, OnInit } from '@angular/core';
import { DrinkanddelightService } from '../drinkanddelight.service';
import { RawMaterialStock } from '../raw-material-stock';

@Component({
  selector: 'app-add-raw-material',
  templateUrl: './add-raw-material.component.html',
  styleUrls: ['./add-raw-material.component.css']
})
export class AddRawMaterialComponent implements OnInit {

  rmaterial:RawMaterialStock = new RawMaterialStock();
  successMessage:String;
  errorMessage:String;
  
  constructor(private dadservice:DrinkanddelightService) { }

  ngOnInit(): void {
  }

  addRawMaterial():void
  {
    this.dadservice.addRawMaterial(this.rmaterial).subscribe((data)=>
      {
        this.successMessage=data;
        this.errorMessage=undefined
      },
      error=>
      {
        this.errorMessage=JSON.parse(error.error).message;
        console.log(error.error);
        this.successMessage=undefined
      }       
      );
  }
}
