import { Supplier } from './supplier';

describe('Supplier', () => {
  it('should create an instance', () => {
    expect(new Supplier()).toBeTruthy();
  });
});
